/*
Implementar en java la clase que se indica en el diagrama de clases (figura), incluyendo las validaciones necesarias
en los métodos consignar y retirar. Crear una clase principal en la que se cree un objeto de dicha clase, se lean por
consola sus atributos y probar sus métodos(también leyendo por consola los valores correspondientes).
 */
package vista;
import java.util.Scanner;
import modelo.Cuenta;
public class main {
    public static void main(String[] args) {
        Cuenta Cuenta=new Cuenta();
        Scanner entrada=new Scanner (System.in); 
        System.out.println("Escriba su numero de cuenta: ");
        int noCuenta= entrada.nextInt();
        Cuenta.setNumeroCuenta(noCuenta);
        System.out.println("Escriba su nombre : ");
        String nombre= entrada.next();
        Cuenta.setNombreCliente(nombre);
        System.out.println("Escriba el saldo de la cuenta: ");
        double saldo= entrada.nextDouble();
        Cuenta.setSaldo(saldo);
        System.out.println("ECOJA UNA OPCION ");
        System.out.println("1.retirar");
        System.out.println("2.consignar");
        System.out.println("-------------");
        int opcion=entrada.nextInt();
        boolean consignar=false;
        boolean retirar=false;
        while (consignar==false && retirar==false){
            if (opcion==1) {
                retirar(Cuenta);
                break;
            }
            else if (opcion==2){
                consignar(Cuenta);
                break;
                }
        }
    }
    public static void consignar(Cuenta Cuenta) {
        Scanner entrada= new Scanner(System.in);
        System.out.println("escriba la cantidad de dinero a consignar : ");
        double monto=entrada.nextDouble();
        Cuenta.setSaldo(Cuenta.getSaldo()+monto);
        System.out.printf("Su saldo actual es:  %.2f\n",Cuenta.getSaldo());
    }
    public static void retirar(Cuenta Cuenta) {
        Scanner entrada=new Scanner (System.in);
        System.out.println("escriba la cantidad de dinero a retirar : ");
        double monto=entrada.nextDouble();
        Cuenta.setSaldo(Cuenta.getSaldo()-monto);
        System.out.printf("Su nuevo saldo es:  %.2f\n",Cuenta.getSaldo());
    }
}
    

