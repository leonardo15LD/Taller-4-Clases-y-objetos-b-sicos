/*
 */
package modelo;

public class Cuenta {
    private int numeroCuenta;
    private String nombreCliente;
    private double Saldo;
    public Cuenta() {
    }
    public int getNumeroCuenta() {
        return numeroCuenta;
    }
    public String getNombreCliente() {
        return nombreCliente;
    }
    public double getSaldo() {
        return Saldo;
    }
    public void setNumeroCuenta(int noCuenta){
        this.numeroCuenta = noCuenta;
    }
    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }
    public void setSaldo(double Saldo) {
        this.Saldo = Saldo;}
    
}
