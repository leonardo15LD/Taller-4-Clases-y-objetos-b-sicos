/*
 Implementar la clase Informe, la cual contiene el reporte de ventas de cada mes de una empresa. Estos reportes se
encuentran almacenados en un vector de tamaño 12, donde el primer elemento contiene el reporte de ventas de enero,
el segundo el reporte de febrero y así sucesivamente. Incluya método constructor, getter y setter y métodos para
calcular: el promedio de ventas del año, el mes con menos ventas, el mes con mayores ventas, el acumulado de ventas
del año. Cree una clase principal en la cual se cree un objeto Informe y se muestre sus resultados.
 */
package vista;
import modelo.*;
public class main {
    public static void main(String[] args) {
        Informe Informe = new Informe();
        Informe.leerVentas(); 
        imprimir(Informe);   
    }
    public static void imprimir(Informe Informe){
        System.out.printf("el promedio es: %.2f\n",Informe.promedio());
        System.out.println("el acumulado de ventas es: "+Informe.sumaTotal());
        System.out.println("el mes con mas ventas fue el :"+Informe.mayorVentas());
        System.out.println("el mes con menos ventas fue el :"+Informe.menorVentas());
    }   
}