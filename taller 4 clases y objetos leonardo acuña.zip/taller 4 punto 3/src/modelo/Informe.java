/*
Implementar la clase Informe, la cual contiene el reporte de ventas de cada mes de una empresa. Estos reportes se
encuentran almacenados en un vector de tamaño 12, donde el primer elemento contiene el reporte de ventas de enero,
el segundo el reporte de febrero y así sucesivamente. Incluya método constructor, getter y setter y métodos para
calcular: el promedio de ventas del año, el mes con menos ventas, el mes con mayores ventas, el acumulado de ventas
del año. Cree una clase principal en la cual se cree un objeto Informe y se muestre sus resultados.
 */
package modelo;
import java.util.Scanner;
public class Informe {
    private double []meses = new double[12];
    Scanner entrada= new Scanner(System.in);
    double suma=0;
    double tamaño;
    public  Informe(){
        this.tamaño=12;  
    }
    
    public double getSuma(){
        return this.suma;
    }
    public void setSuma(double suma){
        this.suma=suma;
    }
    public double getMeses(){
        return  this.getMeses();
    }
    public void setMeses(double meses[]){
        this.meses=meses;
    }
    double promedio;
    public void leerVentas(){
       for (int i=0;i<12;i++){
           System.out.print("escriba el reporte de ventas del mes "+(i+1)+": ");
           meses[i]=entrada.nextDouble();   
       }
    }
    public double promedio(){
        double prom;
        for (int i=0;i<meses.length;i++)
            suma+=meses[i];
        prom=this.suma/this.tamaño;
        return  prom;
    }
    public double sumaTotal(){
        return suma;
    }
    double mayor,menor;
    int pos=-1;
    public double mayorVentas(){
        for (int i=0;i<meses.length;i++){
            if (meses[i]>mayor){
                mayor=meses[i];
                pos=i;
            }
        }
        return (pos+1);
    }
    int pos2=0;
    public double menorVentas(){
        menor=meses[0];
        for (int g=0;g<meses.length;g++){
            if (meses[g]<menor){
                menor=meses[g];
                pos2=g;
            }
        }
        return (pos2+1);
    }
}