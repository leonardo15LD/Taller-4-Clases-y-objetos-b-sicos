/*
Crea una clase Libro que modele la información que se mantiene en una biblioteca sobre cada libro: título, primer
nombre, segundo nombre, primer apellido, ISBN, páginas, edición, ciudad, país, fecha de edición (Sting) y editorial. Los
libros que vamos a construir pertenecen a una misma editorial, por tanto, dicho atributo debe ser definido como variable
de clase de acceso público, y su valor debe ser “Prentice-Hall”. La clase debe proporcionar los siguientes
servicios: constructor por defecto, getters y setters.
Implementar una clase principal, en la cual, además del método main, se debe implementar un método para leer la
información de 5 Libros, los cuales deberán ser almacenados en un vector de tamaño 5, y un método para mostrar la
información de los libros en este formato:
Título: Introduction to Java Programming
3a. edición
Autor: Liang, Y. Daniel
ISBN: 0-13-031997-X
Prentice-Hall
New Jersey (USA), viernes 16 de noviembre de 2001
784 páginas
 */
package vista;
import java.util.Scanner;
import modelo.*;
public class principal {
    private static  String titulo,nombre1,nombre2,apellido,isbn,edicion,ciudad,pais,fecha;
    private static String paginas;
    public static void main(String[] args) {
        leer();
    }
    public static void leer(){
        for(int i=0;i<2;i++){
            Libro libros=new Libro();
            Scanner entrada= new Scanner(System.in);
            System.out.println("----------------------------------------");
            System.out.println("LIBRO "+(i+1));
            System.out.println("titulo: ");
            titulo=entrada.next();
            System.out.println("primer nombre: ");
            nombre1=entrada.next();
            System.out.println("segundo nombre: ");
            nombre2=entrada.next();
            System.out.println("apellido: ");
            apellido=entrada.next();
            System.out.println("ISBN: ");
            isbn=entrada.next();
            System.out.println("ciudad: ");
            ciudad=entrada.next();
            System.out.println("pais: ");
            pais=entrada.next();
            System.out.println("fecha: ");
            fecha=entrada.next();
            System.out.println("paginas: ");
            paginas=entrada.next();
            System.out.println("edicion: ");
            edicion=entrada.next();
            libros.setTitulo(titulo);
            libros.setNombre1(nombre1);
            libros.setNombre2(nombre2);
            libros.setApellido(apellido);
            libros.setIsbn(isbn);
            libros.setPaginas(paginas);
            libros.setEdicion(edicion);
            libros.setCiudad(ciudad);
            libros.setPais(pais);
            libros.setFecha(fecha);
            imprimir(libros);
        }   
    } 
    public static void imprimir(Libro libros){
        System.out.println("Titulo: "+libros.getTitulo());
        System.out.println(""+libros.getEdicion()+"a. Edicion");
        System.out.println("Autor: "+libros.getApellido()+" , "+libros.getNombre1()+" . "+libros.getNombre2());
        System.out.println("ISBN: "+libros.getIsbn());
        System.out.println(Libro.editorial+" , \n"+libros.getCiudad()+"["+libros.getPais()+"] ,"+libros.getFecha() );
        System.out.println(libros.getPaginas()+" Paginas");
    }
    
}
