/*
Crea una clase Libro que modele la información que se mantiene en una biblioteca sobre cada libro: título, primer
nombre, segundo nombre, primer apellido, ISBN, páginas, edición, ciudad, país, fecha de edición (Sting) y editorial. Los
libros que vamos a construir pertenecen a una misma editorial, por tanto, dicho atributo debe ser definido como variable
de clase de acceso público, y su valor debe ser “Prentice-Hall”. La clase debe proporcionar los siguientes
servicios: constructor por defecto, getters y setters.
Implementar una clase principal, en la cual, además del método main, se debe implementar un método para leer la
información de 5 Libros, los cuales deberán ser almacenados en un vector de tamaño 5, y un método para mostrar la
información de los libros en este formato:
Título: Introduction to Java Programming
3a. edición
Autor: Liang, Y. Daniel
ISBN: 0-13-031997-X
Prentice-Hall
New Jersey (USA), viernes 16 de noviembre de 2001
784 páginas
 */
package modelo;

public class Libro {
    private String titulo,nombre1,nombre2,apellido,isbn,edicion,ciudad,pais,fecha;
    private String paginas;
    public static String editorial="Prentice-Hall";
    public Libro(){
        
    }
    public String getTitulo(){
        return titulo;
    }
    public String getNombre1(){
        return nombre1;
    }
    public String getEdicion(){
        return edicion;
    }
    public String getNombre2(){
        return nombre2;
    }
    public String getApellido(){
        return apellido;
    }
    public String getIsbn(){
        return isbn;
    }
    public String getCiudad(){
        return ciudad;
    }
    public String getPais(){
        return pais;
    }
    public String getFecha(){
        return fecha;
    }
    public String getPaginas(){
        return paginas;
    }
    //SETT  
    public void setTitulo(String titulo){
        this.titulo=titulo;
    }
    public void setNombre1(String nombre1){
        this.nombre1=nombre1;
    }
    public void setNombre2(String nombre2){
        this.nombre2=nombre2;
    }
    public void setApellido(String apellido){
        this.apellido=apellido;
    }
    public void setIsbn(String isbn){
        this.isbn=isbn;
    }
    public void setEdicion(String edicion){
        this.edicion=edicion;
    }
    public void setCiudad(String ciudad){
        this.ciudad=ciudad;
    }
    public void setPais(String pais){
        this.pais=pais;
    }
    public void setFecha(String fecha){
        this.fecha=fecha;
    }
    public void setPaginas(String paginas){
        this.paginas=paginas;
    }
}
