
package vista;

import modelo.*;
public class prueba_triangulo {
private double altura,base;
    public static void main(String[] args) {
        triangulo Triangulo=new triangulo();
        Triangulo.leerDatos();
        System.out.println("----------------------------------------------------");
        System.out.printf("el area de triangulo es: %.2f \n",Triangulo.Area());
        System.out.printf("sus lados del triangulo son: %.2f \n",Triangulo.longitud());
        System.out.printf("el perimetro del triangulos es: %.2f \n",Triangulo.perimetro());
        System.out.printf("el valor del angulo vertice es: %.2f \n",Triangulo.Angulo());
    }
    
}
