
package modelo;
import java.util.Scanner;
public class triangulo {
   private double altura,base;
   public triangulo(){
       
   }
   public double getAltura(){
       return this.altura;
   }
   public double getBase(){ 
        return this.base;
   }
   public void setBase(double base){
       this.base = base;
   }
   public void leerDatos(){
       Scanner entrada=new Scanner(System.in);
       System.out.println("escriba la altura del triangulo: ");
       altura=entrada.nextDouble();
       System.out.println("escriba la base del triangulo: ");
       base=entrada.nextDouble();
   }
   public double Area(){
       double area=(this.base*this.altura)/2;
       return area;
   }
   public double longitud (){
       double a= this.base/2;
       double p = (altura*altura)+(a*a);
       double lados = Math.sqrt(p);  
       return  lados;
   }
   public double perimetro(){
       double per;
       per=2*this.longitud()+base;
       return per;
    }
   public double Angulo ( ){
    double valores,angulo ;
    angulo =  altura/this.longitud();
    valores = Math.acos(angulo);
    double a = Math.toDegrees(valores);
    return a*2;
    }
}
