package vista;
import java.util.Scanner;
import modelo.clase_coches;
public class PruebaCoche {
    public static void main(String[] args) {
        Scanner entrada= new Scanner(System.in);
        String color2,marca2,matricula2,modelo2;
        int caballos2,puertas2;
        clase_coches coche=new clase_coches();
        coche.salida();
        System.out.println("-------------------------------------");
        for (int i=0;i<3;i++){
            System.out.print("escriba el color del carro "+(i+1)+": ");
            color2=entrada.next();
            System.out.print("escriba la marca del carro "+(i+1)+": ");
            marca2=entrada.next();
            System.out.print("escriba la matricula del carro "+(i+1)+": ");
            matricula2=entrada.next();
            System.out.print("escriba el modelo del carro "+(i+1)+": ");
            modelo2=entrada.next();
            System.out.print("escriba el numero de caballos del carro "+(i+1)+": ");
            caballos2=entrada.nextInt();
            System.out.print("escriba el numero de puertas del carro "+(i+1)+": ");
            puertas2=entrada.nextInt();
            clase_coches coche2 = new clase_coches();
            coche2.setColor(color2);
            coche2.setMarca(marca2);
            coche2.setModelo(modelo2);
            coche2.setCaballos(caballos2);
            coche2.setPuertas(puertas2);
            coche2.setMatricula(matricula2);
            System.out.println("COCHE "+(i+1));
            coche2.salida();
            System.out.println("-------------------------------------");
        }  
    }    
}
