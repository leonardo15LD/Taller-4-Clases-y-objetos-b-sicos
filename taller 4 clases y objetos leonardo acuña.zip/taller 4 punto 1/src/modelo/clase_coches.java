/*
Crear una clase Coche, a través de la cual se pueda conocer el color del coche, la marca, el modelo, el número de
caballos, el número de puertas y la matricula. Crear el constructor del coche, así como los métodos que considere
necesarios. Crear una clase PruebaCoche que instancie varios coches, cambie sus estados (valores de sus atributos)
y muestre sus datos por pantalla.
 */
package modelo;
public class clase_coches {
    private String color,marca,matricula,modelo;
    private int caballos,puertas;
    public clase_coches(){
        this.color= "negro";
        this.marca="chevrolet";
        this.modelo="2003";
        this.caballos=17;
        this.puertas=4;
        this.matricula="bb18a";
    }
    public void  salida(){
        System.out.println("el color del coche es: "+color);
        System.out.println("la marca del coche es: "+marca);
        System.out.println("el modelo del coche es: "+modelo);
        System.out.println("el numero de caballos del cohe es:"+caballos);
        System.out.println("el numero de puertas del coche es: "+puertas);
        System.out.println("la matricula del coche es: "+matricula);
    }
    public String getColor(){
        return this.color;
    }
    public String getMarca(){
        return this.marca;
    }
    public String getModelo(){
        return this.modelo;
    }
    public int getCaballos(){
        return this.caballos;
    }
    public int getPuertas(){
        return this.puertas;
    }
    public String Matricula(){
        return this.matricula;
    }
    public void setColor(String color){
        this.color=color;  
    }
    public void setMarca(String marca){
        this.marca=marca;  
    }
    public void setModelo(String modelo){
        this.modelo=modelo;  
    }
    public void setCaballos(int caballos){
        this.caballos=caballos;  
    }
    public void setPuertas(int puertas){
        this.puertas=puertas;  
    }
    public void setMatricula(String matricula){
        this.matricula=matricula;  
    }
}