package modelo;
public class ecuacion {
    private int a,b,c,d;
    public int getA(){
        return a;}
    public void setA(int a){
        this.a = a;}
    public int getB(){
        return b;}
    public void setB(int b){
        this.b = b;}
    public int getC(){
        return c;}
    public void getC(int c){
        this.c = c;}
    public int getD(){
        return d;}
    public void setD(int d){
        this.d = d;} 
    public ecuacion(int a, int b, int c, int d){
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    public int getX(){
        int x = a*(d*d^2)+b*d+c;
        return x;
    }
    public String primecu(){
        return "La ecuacion x=("+ a + ")("+ b + "^2)+(" + b + ")(" + d + ")+" + c + " el valor de X es "+getX();
    }
}