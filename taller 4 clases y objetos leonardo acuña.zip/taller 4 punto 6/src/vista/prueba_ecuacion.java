
package vista;
import modelo.*;
public class prueba_ecuacion {
    public static void main(String[] args) {
        System.out.println(new ecuacion(3, 5, 5, 8).primecu());
    }
}
