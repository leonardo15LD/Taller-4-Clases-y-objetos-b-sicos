/*
Diseñar una clase Habitación, con atributos para su largo, ancho y altura en metros. Implemente métodos habituales,
así mismo, un método que permita calcular la cantidad de metros cuadrados que se requiere de enchape para el piso
de la habitación, y otro que calcule cuantos metros cuadrados de papel se requiere para tapizar sus paredes. Crear
una clase PruebaHabitacion, en la cual se instancie un objeto habitación y se muestre por consola sus dimensiones y
los metros cuadrados requeridos para el enchape de su piso y el tapizado de sus paredes.
 */
package vista;
import modelo.*;
import java.util.Scanner;
public class PruebaHabitacion {
    public static void main(String[] args) {
        double largo,ancho,altura;
        Scanner entrada= new Scanner(System.in);
        Habitacion cuarto= new Habitacion();
        System.out.println("----------------------------------------------------------");
        System.out.println("OBJETO 1");
        cuarto.imprimir();
        System.out.println("----------------------------------------------------------");
        System.out.println("OBJETO 2");
        System.out.println("escriba el largo de su habitacion: ");
        largo=entrada.nextDouble();
        System.out.println("escriba el ancho de su habitacion: ");
        ancho=entrada.nextDouble();
        System.out.println("escriba la altura de su habitacion: ");
        altura=entrada.nextDouble();
        System.out.println("----------------------------------------------------------");
        Habitacion cuartos= new Habitacion();
        cuartos.setLargo1(largo);
        cuartos.setAncho1(ancho);
        cuartos.setAltura1(altura);
        cuartos.imprimir();
    }
    
}
