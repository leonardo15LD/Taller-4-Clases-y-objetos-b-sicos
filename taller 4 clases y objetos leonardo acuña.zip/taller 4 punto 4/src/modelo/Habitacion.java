
package modelo;
public class Habitacion {
    private double largo1,ancho1,altura1;
    double largo,ancho,altura;
    public Habitacion(){
        this.largo1=6;
        this.ancho1=7;
        this.altura1=1.80;
    }
    public double getLargo1(){
        return this.largo1;
    }
    public double getAncho1(){
        return this.ancho1;
    }
    public double getAltura1(){
        return this.altura1;
    }
    public void setLargo1(double largo1){
        this.largo1=largo1;
    }
    public void setAncho1(double ancho1){
        this.largo1=ancho1;
    }public void setAltura1(double altura1){
        this.altura1=altura1;
    }
    public double calcularEnchape(){
        double enchape= this.ancho1*this.largo1;
        return enchape;
    }
    public double calcularParedes(){
        double paredes= this.altura1*this.largo1;
        return paredes;
    }
    public void imprimir(){
        System.out.println("altura de la habitacion es : "+altura1);
        System.out.println("ancho de la habitacion es : "+ancho1);
        System.out.println("el largo de la habitacion es : "+largo1);
        System.out.printf("para enchapar el piso de su habaitacion se necesitan: %.2f metros cuadrados\n",calcularEnchape());
        System.out.printf("para enchapar el piso de su habaitacion se necesitan: %.2f metros cuadrados\n",calcularParedes());
    }
    
}
